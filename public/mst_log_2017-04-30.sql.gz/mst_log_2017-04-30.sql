# ************************************************************
# Sequel Pro SQL dump
# バージョン 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# ホスト: 127.0.0.1 (MySQL 5.7.16)
# データベース: mst_log
# 作成時刻: 2017-04-30 07:21:47 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# テーブルのダンプ toots
# ------------------------------------------------------------

DROP TABLE IF EXISTS `toots`;

CREATE TABLE `toots` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `toot_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `toot_display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toot_username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toot_text` text COLLATE utf8mb4_unicode_ci,
  `toot_reblogged` int(11) DEFAULT '0',
  `toot_instance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toot_link_text` text COLLATE utf8mb4_unicode_ci,
  `toot_date` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
